# Protection coverage (collector v2)

This file is **derived analysis**. Raw HTTP bodies are in `raw/`. Do not treat this markdown as the raw export.

This collector is **new and independent**. It is not a restoration of any prior collector, not the same bytes, and does not inherit prior tool review.

Historical `COLLECTOR_INPUT_MISSING` publication `59d10c476de54be81b822d1eb592e7f76955c794` remains a separate observation.

```text
ADOPTION=NOT_PERFORMED
NOT_DECLARED=PASS, ACCEPT, MERGE AUTHORIZED, LIVE AUTHORIZED
```

## Collection window

- started_at: `2026-09-08T17:37:48Z`
- finished_at: `2026-09-08T17:38:25Z`
- actor_login: `danny0971haha` (token not recorded)
- oauth_scopes: `['gist', 'read:org', 'repo', 'workflow']`
- identity drift: `False`
- default_branch: `main`
- expected_context: `trusted-phase2d-freeze-gate`
- known_ruleset_id requested: `21580900`

## Confirmed rules

- `{'kind': 'observed_ruleset', 'id': 21580900, 'complete': True, 'enforcement': 'active', 'include': ['refs/heads/main'], 'expected_context_bindings': [{'context': 'trusted-phase2d-freeze-gate', 'integration_id': 15368, 'strict': False}]}`
- `{'kind': 'observed_classic_pattern', 'id': 'BPR_kwDOUAdvbc4E590T', 'pattern': 'main', 'scope': 'only_default', 'required_checks': [{'context': 'Clean install, static checks, tests, secret scan, and dry-run', 'app_database_id': 15368, 'app_slug': 'github-actions', 'app_name': 'GitHub Actions'}, {'context': 'trusted-phase2d-freeze-gate', 'app_database_id': 15368, 'app_slug': 'github-actions', 'app_name': 'GitHub Actions'}], 'expected_context_bindings': [{'context': 'trusted-phase2d-freeze-gate', 'app_database_id': 15368, 'app_slug': 'github-actions', 'app_name': 'GitHub Actions'}], 'requires_status_checks': True, 'complete': True, 'shape_errors': [], 'allowances_truncated': False}`

## Unconfirmed sources or branches

No remaining source gap in this sequential collection; product non-applicability evidence is recorded separately.

## non-main required context

- conclusion: **NOT_PRESENT_IN_COMPLETE_EXPORT**
- method: Full include/exclude and classic pattern analysis; conservative for complex patterns. Not inferred from a sample of branches.

- basis: Complete applicable sources for verified identities contained no non-main expected-context requirement.

## PR #11 main-only trigger scope conflict

PR #11 adds `branches: [main]` to `.github/workflows/trusted-phase2d-freeze.yml`.
That stops the workflow from running for non-main bases. A conflict exists when a
required check named `trusted-phase2d-freeze-gate` (any app/integration identity) still applies
outside main.

- conflict: **NO_CONFLICT_IN_COMPLETE_EXPORT**
- reason: Complete applicable sources for verified identities contained no non-main expected-context requirement.

Effective rules (rulesets, active only) and classic branch protection are listed separately above.
Neither is treated as a complete substitute for the other.

## Owner adoption prerequisites still missing

- Independent review of PR #11 exact head/base, trusted governance adoption order and context/app bindings is still required.
- Sequential observations are not an atomic settings snapshot; revalidate at adoption.
- ADOPTION is not performed. This tool has no inherited reviewer verdict.

## Interpretation limits

- HTTP 401/403/404/429, malformed bodies, and incomplete pagination are coverage gaps, not 'no rule'.
- Empty arrays are usable only when the request was OK, pagination completed, and the caller had sufficient permission for that source.
- `GET /repos/.../rules/branches/{branch}` omits evaluate/disabled rulesets and does not export classic protection.
- `bypass_actors` omitted means UNKNOWN bypass, not an empty bypass list.
- Sampling existing branches is not used to conclude that every possible non-main name lacks a requirement.

